
#ifndef _TIMER2_H
#define _TIMER2_H

void TIM2_ENABLE_5S(void);

extern int DATA_falg;


#endif
