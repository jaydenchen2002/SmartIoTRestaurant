#ifndef __usart_H
#define __usart_H

#include "stm32f10x.h" 


void UART4_Init(u32 bound);


#endif


