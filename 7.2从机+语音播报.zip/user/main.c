/**
	************************************************************
	************************************************************
	************************************************************
	*	文件名： 	main.c
	*
	*	作者： 		张继瑞
	*
	*	日期： 		2017-05-08
	*
	*	版本： 		V1.0
	*
	*	说明： 		接入onenet，上传数据和命令控制
	*
	*	修改记录：	
	************************************************************
	************************************************************
	************************************************************
**/

//单片机头文件
#include "stm32f10x.h"

//网络协议层
#include "onenet.h"

//网络设备
#include "esp8266.h"

//硬件驱动
#include "delay.h"
#include "beep.h"
#include "usart.h"

//C库
#include <string.h>

//温湿度传感器
#include "timer2.h"
#include "dht11.h"   

//Mesh组网
#include "mesh.h"

//串口屏
#include "hmi.h"


//语音模块
#include "stdio.h"
#include "usart5.h"
#include "syn6288.h"


	// 设备短地址
//	char host_address[3] = {0x11,0x11};  // 主机
//	char slave_address[3] = {0x11,0x21}; // 从机
//	char robot_address[3] = {0x11,0x31}; // 机器人

/*
************************************************************
*	函数名称：	Hardware_Init
*
*	函数功能：	硬件初始化
*
*	入口参数：	无
*
*	返回参数：	无
*
*	说明：		初始化单片机功能以及外接设备
************************************************************
*/
void Hardware_Init(void)
{
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	//中断控制器分组设置

	Delay_Init();									//systick初始化
	
	Usart1_Init(9600);		//串口1，打印信息用
	
	UART4_Init(9600);				//串口屏初始化
	
	Mesh_Init();						//初始化Mesh模块
		
//	Beep_Init();									//蜂鸣器初始化
	
	UART5_Init(9600);				//语音模块初始化
	DelayXms(10);
		
	UsartPrintf(USART_DEBUG, " Hardware init OK\r\n");
	
}

/*
************************************************************
*	函数名称：	main
*
*	函数功能：	
*
*	入口参数：	无
*
*	返回参数：	0
*
*	说明：		
************************************************************
*/
int main(void)
{
	
	// Éè±¸¶ÌµØÖ·
//	char host_address[3] = {0x11,0x11};  // Ö÷»ú
	
	int t=0;
				
	Hardware_Init();				//初始化外围硬件	
	Voice_Announcements(1);
	
//	Beep_Set(BEEP_ON);				//鸣叫提示接入成功
//	DelayXms(250);
//	Beep_Set(BEEP_OFF);
	
	
	while(1)
	{		
		t++;
		if(t >= 200)
		{
//			Mesh_SendData(host_address,"X6");
			t=0;
		}
		DelayXms(10);
	}

}
