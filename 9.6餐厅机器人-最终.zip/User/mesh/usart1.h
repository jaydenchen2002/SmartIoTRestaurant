#ifndef __usart1_H
#define __usart1_H

#include "sys.h" 


void USART1_Init(u32 bound);


#endif


