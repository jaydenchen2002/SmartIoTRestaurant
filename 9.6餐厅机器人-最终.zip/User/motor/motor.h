#ifndef _motor_H
#define _motor_H

#include "sys.h"

extern int Motor_A,Motor_B;

#define PWMA1   TIM4->CCR1  
#define PWMA2   TIM4->CCR2 
#define PWMB1   TIM4->CCR3  
#define PWMB2   TIM4->CCR4


#define Motor_Pin GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;
#define Motor_Port GPIOB

void Motor_GPIO_Config(void);
void TIM4_Motor_PWM_Init(u16 per,u16 prc);
void Set_Pwm_Motor1(int motor_a);
void Set_Pwm_Motor2(int motor_b);
void Car_Stop(void);
void Car_leftrun(void);
void Car_rightrun(void);
void Car_run(void);
void turn_180(void);
void turn_R90(void);
void turn_L90(void);
void Forward(void);

#endif
