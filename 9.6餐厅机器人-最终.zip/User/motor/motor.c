#include "motor.h"
#include "sensor.h"


int Motor_A,Motor_B;

void Motor_GPIO_Config(void)
{
		GPIO_InitTypeDef GPIO_InitStructure;
	
	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE); 
	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE); 
	
	 GPIO_InitStructure.GPIO_Pin=Motor_Pin; //TIM4_CH1~CH4
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;  //复用推挽输出
	 GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	 GPIO_Init(Motor_Port, &GPIO_InitStructure);
}

void TIM4_Motor_PWM_Init(u16 per,u16 prc)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);

	TIM_TimeBaseInitStructure.TIM_Period=per;
	TIM_TimeBaseInitStructure.TIM_Prescaler=prc;
	TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseInitStructure);
	
	TIM_ARRPreloadConfig(TIM4, ENABLE); //ʹ 使能TIMx 在 ARR上的预装载寄存器
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //脉宽调制模式通道1
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //比较输出使能
	TIM_OCInitStructure.TIM_OutputNState=TIM_OutputNState_Disable;//使能互补端输出
	TIM_OCInitStructure.TIM_OCIdleState=TIM_OCIdleState_Reset; //死区后输出状态̬
	TIM_OCInitStructure.TIM_OCNIdleState=TIM_OCNIdleState_Reset;//̬死区后互补端输出状态
	TIM_OCInitStructure.TIM_Pulse = 0; 							//设置待装入捕获比较寄存器的脉冲值ֵ
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //输出极性高
	TIM_OCInitStructure.TIM_OCNPolarity=TIM_OCNPolarity_High; //设置互补端输出极性
	
	TIM_OC1Init(TIM4,&TIM_OCInitStructure);
	TIM_OC1PreloadConfig(TIM4,TIM_OCPreload_Enable);
	
	TIM_OC2Init(TIM4,&TIM_OCInitStructure);
	TIM_OC2PreloadConfig(TIM4,TIM_OCPreload_Enable);
	
	TIM_OC3Init(TIM4,&TIM_OCInitStructure);
	TIM_OC3PreloadConfig(TIM4,TIM_OCPreload_Enable);
	
	TIM_OC4Init(TIM4,&TIM_OCInitStructure);
	TIM_OC4PreloadConfig(TIM4,TIM_OCPreload_Enable);
	
	TIM_ARRPreloadConfig(TIM4,ENABLE);
	TIM_Cmd(TIM4,ENABLE);
	
	TIM_CtrlPWMOutputs(TIM4,ENABLE);
	
	TIM_SetCompare1(TIM4,0);
	TIM_SetCompare2(TIM4,0);
	TIM_SetCompare3(TIM4,0);
	TIM_SetCompare4(TIM4,0);

}

void Car_leftrun(void)
{
		Set_Pwm_Motor1(0);
		Set_Pwm_Motor2(340);
}

void Car_rightrun(void)
{
		Set_Pwm_Motor1(340);
		Set_Pwm_Motor2(0);
}


void Car_Stop(void)
{
	Set_Pwm_Motor1(0);
	Set_Pwm_Motor2(0);	
}

void Car_run(void)
{
	Set_Pwm_Motor1(300);
	Set_Pwm_Motor2(300);	
}

void turn_180(void)
{
	Set_Pwm_Motor1(-400);
	Set_Pwm_Motor2(400);
	delay_ms(1000);
	while(!middle)
	{
		Set_Pwm_Motor1(-400);
		Set_Pwm_Motor2(400);
	}
}
void turn_L90(void)
{
		Set_Pwm_Motor1(-300);
		Set_Pwm_Motor2(450);
		delay_ms(1000);
	
		while(!(left==0&&middle==1&&right==0))
				{
					Set_Pwm_Motor1(-300);
					Set_Pwm_Motor2(450);
				}
	
		
}

void turn_R90(void)
{
		Set_Pwm_Motor1(450);
		Set_Pwm_Motor2(-300);
		delay_ms(1000);
	
		while(!(left==0&&middle==1&&right==0))
				{
					Set_Pwm_Motor1(450);
					Set_Pwm_Motor2(-300);
				}
}
/*-----------------------------------------------------------------
函数名称：
输入参数：左轮PWM、右伦PWM
输出参数：无
函数说明：赋值给PWM寄存器
-----------------------------------------------------------------*/
void Set_Pwm_Motor1(int motor_a)
{
    	if(motor_a<0)			PWMA1=1000,PWMA2=1000+motor_a;
			else 	            PWMA2=1000,PWMA1=1000-motor_a;
}


void Set_Pwm_Motor2(int motor_b)
{
		  if(motor_b<0)			PWMB2=1000,PWMB1=1000+motor_b;
			else 	            PWMB1=1000,PWMB2=1000-motor_b;
}
