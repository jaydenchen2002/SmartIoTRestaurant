#ifndef __SYN6288_H
#define __SYN6288_H

#include "sys.h"


void SYN_FrameInfo(u8 Music, u8 *HZdata);
void YS_SYN_Set(u8 *Info_data);

void song_canstart(void);
void song_canend(void);
void shou_canstart(void);
void shou_canend(void);
void bizhang(void);
#endif
