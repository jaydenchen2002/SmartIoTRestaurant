#ifndef _sensor_H
#define _sensor_H

#include "sys.h"
#include "motor.h"
#include "delay.h"
#include "led.h"

extern u8 stop_flag;
extern u8 turn_flag;

#define left		PCin(8)		//s15
#define right	  PCin(9)		//s16
#define middle		PCin(12)	//s18
#define yali  PFin(2)

#define Sensor_RCC_Port			RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOF
#define Sensor_Port 				GPIOC
#define Sensor_Pin 					GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_12

void Sensor_Init(void);



#endif
