#include "delay.h"
#include "ultrasonsic.h"
#include "sys.h"
#include "usart.h"
#include "motor.h"
#include "sensor.h"
#include "HX711.h"
#include "time.h"
#include "syn6288.h"

extern 	float  length;		//存放距离
extern  u8 end_flag;
extern  u8 delivery_flag;


void test(void);
void Song_Left(void);
void Song_Right(void);
void Shou_Left(void);
void Shou_Right(void);
	

void song_can(void);
void shou_can(void);
void Forward(void);



