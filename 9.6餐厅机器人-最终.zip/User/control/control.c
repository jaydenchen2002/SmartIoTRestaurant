#include "control.h"
#include "connect.h"
#include "mesh.h"

		u8 i=0;
	u8 stop_flag=0;		//1小车stop,0小车run
	u8 back_flag=0;   //1回程，0前往
	u8 turn_flag=1;   //1左转，2右转
	u8 end_flag=1;    //1表示一趟送餐（收餐）结束
	
	u8 delivery_flag=0;		//1为送餐，2为收餐


extern int flag;

//void test(void)
//{
//			/**************************************
//		     测试超声波以及压力传感器
//		**************************************/
//		//length=Hcsr04GetLength();	//获得距离
//		
//		if(length<20.00)
//		{
//			Car_Stop();
//		}
//		else 
//		{
//			Car_run();
//		}
//		delay_ms(10);
//		delay_ms(1000);
//		
//		
//		Get_Weight();
//		if(Weight_Shiwu>500||yali==0)
//		{
//				delay_ms(500);
//				Weight_Shiwu=0;
//				Car_run();
//		}
//		else 
//		{
//			delay_ms(500);
//			Weight_Shiwu=0;
//			Car_Stop();
//		}

//}

void Forward(void)
{
		if(length<25.0) //遇到障碍物停止
		{
			Car_Stop();
			bizhang();
		}
		else             //未识别到餐号的循迹部分
		{
			if(left==1&&right==0)
			{
				Car_leftrun();
			}
			else if(left==0&&right==1)
			{
				Car_rightrun();
			}
			else if(left==1&&right==1&&middle==1)
			{
				Car_Stop();
				delay_ms(1000);
				delay_ms(1000);
				Car_run();
				delay_ms(500);
			}
			else Car_run();

		}
}


//左转送餐函数
void Song_Left(void)
{
		while(end_flag != 1)
		{
		/******************************
			           标志位赋值
		******************************/
			if(length<25.0)//遇到障碍物，停止标志位置1
			{
				Car_Stop();
				stop_flag=1;
				bizhang();
			}
			else stop_flag=0;
			//到达餐位置停止标志位为1，小车停住
			if((left==0&&middle==0&&right==0)&&yali==0)
			{
				Car_Stop();
				song_canend();
				stop_flag=1;
			}
			/******************************
			       小车实现功能
		  ******************************/
			if(stop_flag)//停止标志位为1，使小车停止
			{
				Car_Stop();
			}
			else          //停止标志位为0，循迹
		 {
			 if(left==1&&right==0)
				{
					Car_leftrun();
				}
				else if(left==0&&right==1)
				{
					Car_rightrun();
				}
				//第一次达到需要转弯的十字路口
				else if(left==1&&right==1&&middle==1&&turn_flag==1)
				{
					turn_L90();  //左转90
					turn_flag=2; 
					back_flag=0; //此时正在前往送餐地点
				}
				//第二次到达需要转弯的十字路口
				else if(left==1&&right==1&&middle==1&&turn_flag==2)
				{
					turn_R90();  //右转90
					turn_flag=0;
					back_flag=1;//此时正在返回出发地点
				}
				else 
				{
					Car_run();
				}
		 }
		//到达餐位应停止等待餐盘拿起再返程
		 if(!back_flag&&left==0&&middle==0&&right==0&&/*(Weight_Shiwu<400||*/yali==1)
			{	
//					delay_ms(10);
				if(!back_flag&&left==0&&middle==0&&right==0&&/*(Weight_Shiwu<400||*/yali==1)
				{	

					//旋转180°
					while(!middle)
					{
						Set_Pwm_Motor1(-400);
						Set_Pwm_Motor2(400);
					}
					//小车继续前进
				stop_flag=0;
				}
			}
        //回到出发点
//				delay_ms(100);
			 if(back_flag&&left==0&&middle==0&&right==0)
			 {
				//旋转180°
				while(!right)
					{
						Set_Pwm_Motor1(-400);
						Set_Pwm_Motor2(400);
					}
				//小车停止
				end_flag=1;
				break;
			 }
			
			
		  
		}
}

//右转送餐函数
void Song_Right()
{
	while(end_flag != 1)
	{
		/******************************
			           标志位赋值
		******************************/
			if(length<25.0)//遇到障碍物，停止标志位置1
			{
				Car_Stop();
				stop_flag=1;
				bizhang();
			}
			else stop_flag=0;
		//到达餐位位置停止标志位为1，小车停住
		if((left==0&&middle==0&&right==0)&&yali==0)
		{
			Car_Stop();
			song_canend();
			stop_flag=1;
		}	
		/******************************
			       小车实现功能
		******************************/
		if(stop_flag)//停止标志位为1,使小车停止行动
		{
			Car_Stop();
		}
		else          //停止标志位为0，小车循迹
	 {
		 if(left==1&&right==0)
			{
				Car_leftrun();
			}
			else if(left==0&&right==1)
			{
				Car_rightrun();
			}
			//第一次达到需要转弯的十字路口
			else if(left==1&&right==1&&middle==1&&turn_flag==1)
			{
				turn_R90(); //右转90
				turn_flag=2; 
				back_flag=0; //此时正在前往送餐地点
			}
			//第二次到达需要转弯的十字路口
			else if(left==1&&right==1&&middle==1&&turn_flag==2)
			{
				turn_L90(); //左转90 
				turn_flag=0;
				back_flag=1;//此时正在返回出发地点
			}
			else 
			{
				Car_run();
			}
	 }
	//到达餐位应停止等待餐盘拿起再返程 
			 if(!back_flag&&left==0&&middle==0&&right==0&&/*(Weight_Shiwu<400||*/yali==1)
			 {
				//旋转180°
				while(!middle)
				{
					Set_Pwm_Motor1(400);
					Set_Pwm_Motor2(-400);
				}
				//继续前进
			  stop_flag=0;
			  }
	//回到出发点
//				delay_ms(100);
			 if(back_flag&&left==0&&middle==0&&right==0)
			 {
				//旋转180°
				while(!right)
					{
						Set_Pwm_Motor1(-400);
						Set_Pwm_Motor2(400);
					}
				//小车停止
				end_flag=1;
				break;
			 }
			
	}
}




//左转收餐函数
void 	Shou_Left(void)
{
		while(end_flag != 1)
		{
	
			/******************************
			           标志位赋值
			******************************/
			if(length<25.0)//遇到障碍物，停止标志位置1
			{
				Car_Stop();
				stop_flag=1;
				bizhang();
			}
			else stop_flag=0;
			//到达餐位置停止标志位为1，小车停住
			if((left==0&&middle==0&&right==0)&&yali==1)
			{
				Car_Stop();
				stop_flag=1;
				shou_canend();
			}
			/******************************
			       小车实现功能
			******************************/
			if(stop_flag) //停止标志位为1或者结束标志位为1,使小车停止行动
			{
				Car_Stop();	
			}
		 else           //停止标志位为0,小车循迹
		 {
			 if(left==1&&right==0)
				{
					Car_leftrun();
				}
				else if(left==0&&right==1)
				{
					Car_rightrun();
				}
				//第一次达到需要转弯的十字路口
				else if(left==1&&right==1&&middle==1&&turn_flag==1)
				{
					turn_L90();  //左转90
					turn_flag=2; 
					back_flag=0; //此时正在前往送餐地点
				}
				//第二次到达需要转弯的十字路口
				else if(left==1&&right==1&&middle==1&&turn_flag==2)
				{
					turn_R90();  //右转90
					turn_flag=0;
					back_flag=1;//此时正在返回出发地点
				}
				else 
				{
					Car_run();
				}
		 }
		//到达餐位应停止等待餐盘放下再返程
		 if(!back_flag&&left==0&&middle==0&&right==0&&yali==0)  //yali==0表示餐品放下
			{
//					delay_ms(10);
					while(!middle)
					{
						Set_Pwm_Motor1(-400);
						Set_Pwm_Motor2(400);
					}
					//继续前进
				stop_flag=0;
			}
			//回到出发点
				delay_ms(100);
			 if(back_flag&&left==0&&middle==0&&right==0)
			 {
				//旋转180°
				while(!right)
					{
						Set_Pwm_Motor1(-400);
						Set_Pwm_Motor2(400);
					}
				//小车停止
				end_flag=1;
				break;
			 }
	}
}	

//右转收餐函数
void Shou_Right()
{
	while(end_flag != 1)
	{
		/******************************
			           标志位赋值
		******************************/
		if(length<25.0)//运到障碍物，停止标志位置1
			{
				Car_Stop();
				stop_flag=1;
				bizhang();
			}
			else stop_flag=0;
		//到达餐位置停止标志位为1，小车停住
		if((left==0&&middle==0&&right==0)&&yali==1)
		{
			Car_Stop();
			stop_flag=1;
			shou_canend();
		}	
		
		
		/******************************
			       小车实现功能
			******************************/
		if(stop_flag)//停止标志位或结束标志位为1,使小车停止行动
		{
			Car_Stop();
		}
		else          //停止标志位为0，小车循迹
	  {
		 if(left==1&&right==0)
			{
				Car_leftrun();
			}
			else if(left==0&&right==1)
			{
				Car_rightrun();
			}
			//第一次达到需要转弯的十字路口
			else if(left==1&&right==1&&middle==1&&turn_flag==1)
			{
				turn_R90(); //右转90
				turn_flag=2; 
				back_flag=0; //此时正在前往送餐地点
			}
			//第二次到达需要转弯的十字路口
			else if(left==1&&right==1&&middle==1&&turn_flag==2)
			{
				turn_L90(); //左转90 
				turn_flag=0;
				back_flag=1;//此时正在返回出发地点
			}
			else 
			{
				Car_run();
			}
	 }
	//到达餐位应停止等待餐盘放下再返程
	 if(!back_flag&&left==0&&middle==0&&right==0&&yali==0)
		{	
//				delay_ms(10);
				//旋转180°
				while(!middle)
				{
					Set_Pwm_Motor1(400);
					Set_Pwm_Motor2(-400);
				}
				//继续前进
			stop_flag=0;
		
		}
		//回到出发点
//	 delay_ms(100);
	 if(back_flag&&left==0&&middle==0&&right==0)
		{
			//旋转180
			while(!right)
				{
					Set_Pwm_Motor1(-400);
					Set_Pwm_Motor2(400);
				}
			//结束标志位置1（使小车停在出发点）
			end_flag=1;
			break;
		}
	}
}






unsigned int a,b;
void song_can(void)
{
	while(yali);   //等待餐盘放下
	if(a++==0)
	song_canstart();
			if(r=='L')    //餐位在左边
			{
				Song_Left();
			}
			else if(r=='R')    //餐位在右边
			{
				Song_Right();
			}
			else Forward();
}	



void shou_can(void)
{
	while(!yali); 	//等待餐盘拿起
	if(b++==0)
	{
		shou_canstart();
	}
	
			if(r=='L')    //餐位在左边
			{
				Shou_Left();
			}
			else if(r=='R')    //餐位在右边
			{
				Shou_Right();
			}
			else Forward();
}







