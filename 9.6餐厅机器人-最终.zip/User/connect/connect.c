#include "connect.h"
#include "control.h"

void USART2_Init(u32 bound)
{
   //GPIO׋ࠚʨ׃
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
 
	
	/*  Ƥ׃GPIOքģʽۍIOࠚ */
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_2;//TX			   //ԮࠚˤԶPA9
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;	    //شԃΆάˤԶ
	GPIO_Init(GPIOA,&GPIO_InitStructure);  /* ԵʼۯԮࠚˤɫIO */
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_3;//RX			 //ԮࠚˤɫPA10
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;		  //ģŢˤɫ
	GPIO_Init(GPIOA,&GPIO_InitStructure); /* ԵʼۯGPIO */
	

   //USART2 Եʼۯʨ׃
	USART_InitStructure.USART_BaudRate = bound;//Ҩ͘Êʨ׃
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//ؖӤΪ8λ˽ߝٱʽ
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//һٶֹͣλ
	USART_InitStructure.USART_Parity = USART_Parity_No;//ϞǦżУҩλ
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//ϞӲݾ˽ߝ·࠘׆
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	//˕עģʽ
	USART_Init(USART2, &USART_InitStructure); //ԵʼۯԮࠚ2
	
	USART_Cmd(USART2, ENABLE);  //ʹŜԮࠚ2 
	
	USART_ClearFlag(USART2, USART_FLAG_TC);
		
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);//ߪǴРژא׏

	//Usart2 NVIC Ƥ׃
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;//Ԯࠚ1א׏ͨր
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=3;//ȀռԅЈܶ3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority =3;		//ؓԅЈܶ3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨրʹŜ
	NVIC_Init(&NVIC_InitStructure);	//ٹߝָ֨քӎ˽ԵʼۯVIC݄զǷb	
}

	u8 r;

void USART2_IRQHandler(void)                	//Ԯࠚ2א׏ؾϱԌѲ
{
	if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)  //ޓ˕א׏
	{
	r =USART_ReceiveData(USART2);//(USART2->DR);	//ׁȡޓ˕սք˽ߝ
//	end_flag=0;
//	USART_SendData(USART2,'3');
//	while(USART_GetFlagStatus(USART2,USART_FLAG_TC) != SET);
	USART_ClearFlag(USART2,USART_FLAG_TC);
	} 

} 	
