#ifndef _connect_H
#define _connect_H

#include "sys.h"
#include "delay.h"

extern 	u8 r;

extern u8 stop_flag;
extern u8 turn_flag;

void USART2_Init(u32 bound);



#endif
