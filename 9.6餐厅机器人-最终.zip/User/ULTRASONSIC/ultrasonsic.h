#ifndef __ULTRASONSIC_H
#define __ULTRASONSIC_H

#include "sys.h"
#define TRIG_Send  PCout(1)//����˿�ΪPF0
#define ECHO_Reci  PCin(2)//����˿�ΪPF1

float Senor_Using(void);
void  TIM3_Int_Init(void);
 

#endif
