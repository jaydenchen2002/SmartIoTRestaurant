#ifndef _time_H
#define _time_H

#include "sys.h"

void TIM2_Init(u16 per,u16 psc);


void TIM4_Int_Init(u16 arr,u16 psc);
#endif
