#include "control.h"
#include "connect.h"
#include "mesh.h"
#include "syn6288.h"
#include "usart1.h"		 


float length=0;
int flag=0;           //0前进，1进入左转函数，2进入右转函数


int main(void)
{	
	
//	char host_address[3] = {0x11,0x11};  // Ö÷»ú
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 	
	delay_init();
	
	USART1_Init(9600);
	
	Motor_GPIO_Config(); 
	TIM4_Motor_PWM_Init(1000,5);
	
	Mesh_Init();
	
	Sensor_Init();//循迹
	TIM3_Int_Init();//超声波
	
//	Init_HX711pin();
//	Get_Maopi();				
//	delay_ms(1000);
//	delay_ms(1000);
//	Get_Maopi();	                                                                                                             
	UART4_Init(9600);  //语言模块使用的串口初始化，定时器5初始化；在定时器中使用语音模块
	delay_ms(10);
	TIM2_Init(1000,36000-1);//500ms
	USART2_Init(115200);
	
//	robot_Init();
	
//		delay_ms(1000);
//		delay_ms(1000);
//		delay_ms(1000);
//		
//		Mesh_SendData(host_address,(char *)'Y');
//		send();

	
	
	while(1)
	{
		if(!end_flag)
		{
			if(delivery_flag == 2)
			shou_can();
			if(delivery_flag == 1)
			song_can();
		}
		else 
			Car_Stop();

//		if(left==1&&right==0)
//			{
//				Car_leftrun();
//			}
//			else if(left==0&&right==1)
//			{
//				Car_rightrun();
//			}
//			else if(left==1&&right==1&&middle==1)
//			{
//				Set_Pwm_Motor1(-300);
//				Set_Pwm_Motor2(450);
//				delay_ms(1000);
//	
//				while(!(left==0&&middle==1&&right==0))
//				{
//					Set_Pwm_Motor1(-300);
//					Set_Pwm_Motor2(450);
//				}
//			}
//			else if(left==0&&right==0&&middle==0)
//			{
//				turn_180();
//			}
//			else 
//			{
//				Set_Pwm_Motor1(350);
//				Set_Pwm_Motor2(350);	
//			}
//		
	}
		
} 
